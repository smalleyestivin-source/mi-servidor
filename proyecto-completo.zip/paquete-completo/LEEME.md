# Cómo subir esto — guía rápida

Este paquete tiene 4 carpetas. Cada una va a un lugar DISTINTO — no se mezclan.
Cuando yo te dé archivos nuevos de aquí en adelante, siempre te voy a decir a
cuál de estas 4 carpetas pertenece, para que sepas dónde pegarlo.

---

## 📁 1-servidor-principal/
**A dónde va:** tu repo principal de GitHub → conectado a Render (`mi-servidor`)

Este es tu servidor de siempre: IA, ejecución de código, traducción, imágenes,
matchmaking, voces, búsqueda web, Marketplace. Todo lo que ya armamos vive aquí.

Sube estos 6 archivos a tu repo, reemplazando los que ya tengas ahí.

---

## 📁 2-appforge-generador-apk/
**A dónde va:** un repo SEPARADO en GitHub → conectado a un segundo servicio en Render

Este es el generador de APKs (AppForge). Es un proyecto aparte porque hace algo
distinto (recibe HTML, lo manda a compilar). No lo mezcles con el servidor
principal.

Dentro de esta carpeta hay otra llamada `github-actions-repo-aparte/` — esa
NO va aquí tampoco, va en un TERCER repo (ver abajo).

---

## 📁 2-appforge-generador-apk/github-actions-repo-aparte/
**A dónde va:** un repo NUEVO, aparte, en GitHub (puede ser público)

Solo tiene `build-apk.yml`. Va en la ruta exacta:
`.github/workflows/build-apk.yml` dentro de ese repo nuevo.
Este es el que usa GitHub Actions para compilar el APK con Android SDK real.

---

## 📁 3-frontend-paneles/
**A dónde va:** donde tú quieras verlos — no necesitan servidor propio

- `servidor-arquitectura.html` — el panel/dashboard de tu servidor, con el
  panel en vivo, configurar modelos, diagnóstico, SDK.
- `configurar-modelos.html` — la pantalla de configurar modelos por separado.

Puedes abrirlos directo en tu tablet, o subirlos a la carpeta `public/` de tu
servidor principal si quieres que tengan una URL propia.

---

## 📁 4-gameverse/
**A dónde va:** su propio repo (o el mismo que ya tenías para GameVerse)

`GameVerse_v3-25.html` — tu juego multijugador con PeerJS, matchmaking real,
y conexión a tu propio servidor de señalización.

---

## Recordatorio de las variables de entorno (van en Render, nunca en el código)

Servidor principal necesita: `GROQ_API_KEY`, `OPENROUTER_API_KEY`,
`HUGGINGFACE_API_KEY`, `DEEPSEEK_API_KEY`, `MISTRAL_API_KEY`, `COHERE_API_KEY`,
`TOGETHER_API_KEY`, `MONGODB_URI`, `FIREBASE_DB_URL`, `FIREBASE_DB_SECRET`,
`APP_KEY`, `BUILD_CALLBACK_SECRET`, `GITHUB_OWNER`, `GITHUB_REPO`, `GITHUB_PAT`,
`SEARXNG_URLS`.

No hace falta tener todas — las que falten simplemente no se usan, nada se rompe.

const { getDb } = require('../db/database');

async function findUserByApiKey(apiKey) {
  const db = getDb();
  return await db.get('SELECT * FROM users WHERE apiKey = ?', apiKey);
}

async function createUser(email, apiKey) {
  const db = getDb();
  await db.run('INSERT INTO users (email, apiKey) VALUES (?, ?)', [email, apiKey]);
  return { email, apiKey };
}

module.exports = { findUserByApiKey, createUser };

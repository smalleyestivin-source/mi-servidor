const express = require('express');
const router = express.Router();
const { createUser } = require('../models/User');
const { generateUniqueApiKey } = require('../services/apiKeyGenerator');

// Registro simple: da un email, recibe una API key
// (esto también faltaba — nada creaba usuarios todavía)
router.post('/register', async (req, res) => {
    try {
        const { email } = req.body;
        if (!email) return res.status(400).json({ error: 'Email requerido' });
        const apiKey = await generateUniqueApiKey();
        const user = await createUser(email, apiKey);
        res.json({ success: true, apiKey: user.apiKey });
    } catch (e) {
        res.status(500).json({ error: e.message });
    }
});

module.exports = router;

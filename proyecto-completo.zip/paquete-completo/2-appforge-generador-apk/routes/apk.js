const express = require('express');
const router = express.Router();
const multer = require('multer');
const fs = require('fs-extra');
const path = require('path');
const archiver = require('archiver');
const unzipper = require('unzipper');
const { v4: uuidv4 } = require('uuid');
const { authenticateSessionToken } = require('../middlewares/auth');
const { scanProject } = require('../services/securityScanner');
const { dispararBuildEnGithub } = require('../services/apkBuilderGithub');

const upload = multer({ dest: '/tmp/uploads/' });
const PENDING_DIR = path.join(__dirname, '../downloads/pending');
const DOWNLOADS_DIR = path.join(__dirname, '../downloads');

// ── Recibe el ZIP del usuario, lo escanea, y dispara el build en GitHub Actions ──
router.post('/generate-apk', authenticateSessionToken, upload.single('project'), async (req, res) => {
    const sessionId = uuidv4();
    const extractPath = path.join('/tmp', `project-${sessionId}`);

    try {
        await fs.ensureDir(extractPath);
        await fs.createReadStream(req.file.path).pipe(unzipper.Extract({ path: extractPath })).promise();

        const scan = await scanProject(extractPath);
        if (!scan.safe) {
            await fs.remove(extractPath);
            await fs.remove(req.file.path);
            return res.status(400).json({ error: 'Proyecto inseguro', details: scan.issues });
        }

        // Empaquetar en un zip temporal para que el runner de GitHub Actions lo descargue
        await fs.ensureDir(PENDING_DIR);
        const pendingZipPath = path.join(PENDING_DIR, `${sessionId}.zip`);
        await new Promise((resolve, reject) => {
            const output = fs.createWriteStream(pendingZipPath);
            const archive = archiver('zip');
            output.on('close', resolve);
            archive.on('error', reject);
            archive.pipe(output);
            archive.directory(extractPath, false);
            archive.finalize();
        });

        const baseUrl = process.env.PUBLIC_URL || `${req.protocol}://${req.get('host')}`;
        const metadata = {
            name: req.body.name || 'App',
            backgroundColor: req.body.backgroundColor || '#ffffff'
        };

        await dispararBuildEnGithub({
            sessionId,
            projectZipUrl: `${baseUrl}/builds/pending/${sessionId}.zip`,
            appName: metadata.name,
            backgroundColor: metadata.backgroundColor,
            callbackUrl: `${baseUrl}/api/build-callback/${sessionId}`
        });

        res.json({ success: true, sessionId, status: 'building' });

    } catch (error) {
        console.error('Error:', error);
        res.status(500).json({ error: error.message });
    } finally {
        fs.remove(req.file?.path).catch(() => {});
        fs.remove(extractPath).catch(() => {});
    }
});

// ── El runner de GitHub Actions descarga el proyecto pendiente desde aquí ──
router.get('/builds/pending/:sessionId.zip', (req, res) => {
    const filePath = path.join(PENDING_DIR, `${req.params.sessionId}.zip`);
    if (fs.existsSync(filePath)) res.download(filePath);
    else res.status(404).json({ error: 'Zip pendiente no encontrado (¿ya expiró?)' });
});

// ── GitHub Actions manda aquí el APK ya compilado, al terminar ──
// Protegido con un secreto compartido para que nadie más pueda mandar un APK falso.
router.post('/api/build-callback/:sessionId',
    express.raw({ type: 'application/octet-stream', limit: '200mb' }),
    async (req, res) => {
        const secreto = req.headers['x-build-secret'];
        if (!process.env.BUILD_CALLBACK_SECRET || secreto !== process.env.BUILD_CALLBACK_SECRET) {
            return res.status(401).json({ error: 'Secreto de build inválido o ausente' });
        }
        try {
            await fs.ensureDir(DOWNLOADS_DIR);
            const destPath = path.join(DOWNLOADS_DIR, `${req.params.sessionId}.apk`);
            await fs.writeFile(destPath, req.body);
            fs.remove(path.join(PENDING_DIR, `${req.params.sessionId}.zip`)).catch(() => {});
            res.json({ recibido: true });
        } catch (e) {
            res.status(500).json({ error: e.message });
        }
    }
);

// ── Descargar el APK ya compilado ──
router.get('/downloads/:sessionId.apk', async (req, res) => {
    const filePath = path.join(DOWNLOADS_DIR, `${req.params.sessionId}.apk`);
    if (await fs.pathExists(filePath)) res.download(filePath);
    else res.status(404).json({ error: 'APK no listo todavía (o no existe)' });
});

module.exports = router;

const express = require('express');
const router = express.Router();
const { v4: uuidv4 } = require('uuid');

// Crea un token de sesión temporal para usuarios anónimos
// (esto faltaba — sin esto, authenticateSessionToken nunca
// tenía nada válido que revisar)
router.post('/session/start', (req, res) => {
    if (!global.sessions) global.sessions = new Map();
    const token = uuidv4();
    const expires = Date.now() + 24 * 60 * 60 * 1000; // 24 horas
    global.sessions.set(token, { createdAt: Date.now(), expires });
    res.json({ token, expiresAt: expires });
});

module.exports = router;

const sqlite3 = require('sqlite3');
const { open } = require('sqlite');
const path = require('path');
const fs = require('fs-extra');

let db;

async function openDb() {
  const dbPath = path.join(__dirname, 'appforge.db');
  await fs.ensureDir(path.dirname(dbPath));
  db = await open({
    filename: dbPath,
    driver: sqlite3.Database
  });
  
  // Tabla de usuarios (para API Key si se necesita en el futuro)
  await db.exec(`
    CREATE TABLE IF NOT EXISTS users (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      email TEXT UNIQUE,
      apiKey TEXT UNIQUE,
      createdAt DATETIME DEFAULT CURRENT_TIMESTAMP
    );
    CREATE INDEX IF NOT EXISTS idx_apiKey ON users(apiKey);
  `);
  
  return db;
}

function getDb() { return db; }

module.exports = { openDb, getDb };
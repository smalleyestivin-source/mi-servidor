const sharp = require('sharp');
const fs = require('fs-extra');
const path = require('path');

async function generateIcons(sourceImage, outputDir) {
  const sizes = [72, 96, 128, 144, 152, 192, 384, 512];
  const icons = [];
  await fs.ensureDir(outputDir);
  
  for (const size of sizes) {
    const outputPath = path.join(outputDir, `icon-${size}x${size}.png`);
    if (!sourceImage || !await fs.pathExists(sourceImage)) {
      const svg = `<svg width="${size}" height="${size}" xmlns="http://www.w3.org/2000/svg">
        <rect width="100%" height="100%" fill="#4A90E2"/>
        <text x="50%" y="50%" text-anchor="middle" dy=".3em" fill="white" font-size="${size/2}">📱</text>
      </svg>`;
      await sharp(Buffer.from(svg)).png().toFile(outputPath);
    } else {
      await sharp(sourceImage).resize(size, size).png().toFile(outputPath);
    }
    icons.push({ src: `icons/icon-${size}x${size}.png`, sizes: `${size}x${size}`, type: 'image/png' });
  }
  return icons;
}

module.exports = { generateIcons };
const { exec } = require('child_process');
const util = require('util');
const fs = require('fs-extra');
const path = require('path');
const execPromise = util.promisify(exec);

async function buildApk(projectPath, metadata, sessionId) {
  const androidProjectPath = path.join('/tmp', `android-${sessionId}`);
  const outputApkPath = path.join('/tmp', `apk-${sessionId}.apk`);
  
  try {
    console.log(`[${sessionId}] Iniciando build APK con Capacitor`);
    await fs.ensureDir(androidProjectPath);
    
    // package.json
    const packageJson = {
      name: metadata.name.toLowerCase().replace(/[^a-z0-9]/g, ''),
      version: "1.0.0",
      private: true,
      dependencies: {
        "@capacitor/android": "^5.7.0",
        "@capacitor/core": "^5.7.0"
      },
      scripts: { build: "echo 'Build completed'" }
    };
    await fs.writeJson(path.join(androidProjectPath, 'package.json'), packageJson, { spaces: 2 });
    
    // capacitor.config.json
    const capacitorConfig = {
      appId: `com.appforge.${metadata.name.toLowerCase().replace(/[^a-z]/g, '')}`,
      appName: metadata.name,
      webDir: "www",
      server: { androidScheme: "https" },
      plugins: { SplashScreen: { launchShowDuration: 2000, backgroundColor: metadata.backgroundColor || "#ffffff" } }
    };
    await fs.writeJson(path.join(androidProjectPath, 'capacitor.config.json'), capacitorConfig, { spaces: 2 });
    
    console.log(`[${sessionId}] Instalando dependencias npm`);
    await execPromise('npm install', { cwd: androidProjectPath, timeout: 120000 });
    
    console.log(`[${sessionId}] Añadiendo plataforma Android`);
    await execPromise('npx cap add android', { cwd: androidProjectPath, timeout: 180000 });
    
    // Copiar archivos del usuario
    const wwwPath = path.join(androidProjectPath, 'www');
    await fs.ensureDir(wwwPath);
    await fs.copy(projectPath, wwwPath, { filter: src => !path.basename(src).startsWith('.') });
    
    const indexPath = path.join(wwwPath, 'index.html');
    if (!await fs.pathExists(indexPath)) throw new Error('index.html no encontrado');
    
    console.log(`[${sessionId}] Sincronizando Capacitor`);
    await execPromise('npx cap sync android', { cwd: androidProjectPath, timeout: 120000 });
    
    // Compilar APK
    const androidPath = path.join(androidProjectPath, 'android');
    const gradlewPath = path.join(androidPath, 'gradlew');
    if (await fs.pathExists(gradlewPath)) {
      if (process.platform !== 'win32') await execPromise(`chmod +x ${gradlewPath}`);
      console.log(`[${sessionId}] Compilando APK (esto puede tardar varios minutos)`);
      await execPromise(`./gradlew assembleDebug`, { cwd: androidPath, timeout: parseInt(process.env.BUILD_TIMEOUT_MS) || 900000 });
    } else {
      throw new Error('gradlew no encontrado');
    }
    
    // Localizar APK generado
    const apkPathCandidates = [
      path.join(androidPath, 'app', 'build', 'outputs', 'apk', 'debug', 'app-debug.apk'),
      path.join(androidPath, 'app', 'build', 'outputs', 'apk', 'release', 'app-release.apk')
    ];
    let finalApkPath = null;
    for (const candidate of apkPathCandidates) {
      if (await fs.pathExists(candidate)) {
        finalApkPath = candidate;
        break;
      }
    }
    if (!finalApkPath) throw new Error('No se encontró el APK generado');
    
    await fs.copy(finalApkPath, outputApkPath);
    console.log(`[${sessionId}] APK generado exitosamente: ${outputApkPath}`);
    return outputApkPath;
    
  } catch (error) {
    console.error(`[${sessionId}] Error en build: ${error.message}`);
    throw error;
  }
}

module.exports = { buildApk };
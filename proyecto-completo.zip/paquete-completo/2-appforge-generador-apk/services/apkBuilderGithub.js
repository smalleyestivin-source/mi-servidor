// ============================================================
// COMPILAR EL APK EN GITHUB ACTIONS (no en este servidor)
// Necesitas un repo aparte en GitHub con el workflow
// build-apk.yml (te lo dejo en otro archivo) y estas variables
// en Render → Environment:
//   GITHUB_OWNER=tu-usuario-de-github
//   GITHUB_REPO=nombre-del-repo-donde-esta-el-workflow
//   GITHUB_PAT=tu-token-personal-con-permisos-repo-y-workflow
// ============================================================

const GITHUB_OWNER = process.env.GITHUB_OWNER;
const GITHUB_REPO = process.env.GITHUB_REPO;
const GITHUB_PAT = process.env.GITHUB_PAT;
const WORKFLOW_FILE = 'build-apk.yml';

async function dispararBuildEnGithub({ sessionId, projectZipUrl, appName, backgroundColor, callbackUrl }) {
    if (!GITHUB_PAT || !GITHUB_OWNER || !GITHUB_REPO) {
        throw new Error('Faltan GITHUB_OWNER, GITHUB_REPO o GITHUB_PAT en las variables de entorno');
    }

    const res = await fetch(
        `https://api.github.com/repos/${GITHUB_OWNER}/${GITHUB_REPO}/actions/workflows/${WORKFLOW_FILE}/dispatches`,
        {
            method: 'POST',
            headers: {
                'Authorization': `Bearer ${GITHUB_PAT}`,
                'Accept': 'application/vnd.github+json',
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                ref: 'main',
                inputs: {
                    session_id: sessionId,
                    project_zip_url: projectZipUrl,
                    app_name: appName,
                    background_color: backgroundColor,
                    callback_url: callbackUrl
                }
            })
        }
    );

    // GitHub responde 204 (sin contenido) si aceptó disparar el workflow
    if (res.status !== 204) {
        const detalle = await res.text();
        throw new Error(`GitHub Actions no aceptó el build (HTTP ${res.status}): ${detalle}`);
    }
    return true;
}

module.exports = { dispararBuildEnGithub };

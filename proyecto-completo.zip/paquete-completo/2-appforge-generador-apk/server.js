require('dotenv').config();
const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const compression = require('compression');

const { openDb } = require('./db/database');
const { initBuildQueue } = require('./services/buildQueue');
const { cleanupOldFiles } = require('./services/cleanup');
const errorHandler = require('./middlewares/errorHandler');
const rateLimiter = require('./middlewares/rateLimiter');

const authRoutes = require('./routes/auth');
const sessionRoutes = require('./routes/session');
const apkRoutes = require('./routes/apk');

const app = express();
const PORT = process.env.PORT || 3000;

// Sesiones anónimas en memoria (se reinician si el servidor reinicia — normal)
global.sessions = new Map();

app.use(helmet());
app.use(compression());
app.use(cors());
app.use(express.json());
app.use(rateLimiter);

app.use('/', authRoutes);
app.use('/', sessionRoutes);
app.use('/', apkRoutes);

app.get('/health', (req, res) => res.json({ status: 'ok', servicio: 'appforge' }));

app.use(errorHandler);

async function iniciar() {
    await openDb();
    initBuildQueue();
    setInterval(cleanupOldFiles, parseInt(process.env.CLEANUP_INTERVAL_MS) || 60 * 60 * 1000);
    app.listen(PORT, () => console.log(`🚀 AppForge escuchando en puerto ${PORT}`));
}

iniciar();

module.exports = app;
